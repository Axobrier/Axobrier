/**
 * @file axobrier.h
 * @brief Axobrier System 1 Decision Engine — Primary Public Header
 */

#ifndef AXOBRIER_H
#define AXOBRIER_H

#include "axobrier_core.h"

#endif /* AXOBRIER_H */
